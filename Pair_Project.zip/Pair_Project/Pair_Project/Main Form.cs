﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

/*App Name: Calculator App
 *Purpose: to Perform Calculations
 *Date: 04/07/2021
 *Dev Names: Nick Hornsby and Shadi Jabbour */

namespace Pair_Project
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        //Declares some global variables
        int x, y;
        double output;

        //Click event handler for the add button
        private void addButton_Click(object sender, EventArgs e)
        {
            //Parses text box input as x and y respectively
            int.TryParse(xTextBox.Text, out x);
            int.TryParse(yTextBox.Text, out y);

            //Checks to see if values have been entered in the y and x text boxes.
            if (xTextBox.Text == "" || yTextBox.Text == "")
            {
                DialogResult dialog = MessageBox.Show("Error: Please enter a value in the necessary text box(es).", this.Text,
                                MessageBoxButtons.OK, MessageBoxIcon.Warning);
                if (dialog == DialogResult.Yes) this.Close();
            }

            else
            {
                //Adds x and y and outputs it to the listbox
                output = x + y;
                listBox.Items.Add("Sum of " + x + " and " + y + ": " + output);
            }

        }

        //Click event handler for the factorial button
        private void facButton_Click(object sender, EventArgs e)
        {
            //Parses text box input as x, declares integer dX
            int.TryParse(xTextBox.Text, out x);
            int dX = x;
            
            //Checks to see if values have been entered in the y and x text boxes.
            if (xTextBox.Text == "" || yTextBox.Text == "")
            {
                DialogResult dialog = MessageBox.Show("Error: Please enter a value in the necessary text box(es).", this.Text,
                                MessageBoxButtons.OK, MessageBoxIcon.Warning);
                if (dialog == DialogResult.Yes) this.Close();
            }
            else
            {
                //Displays error message is x is greater than 10
                if (x > 10)
                {
                    DialogResult dialog = MessageBox.Show("Error: Please enter a value between no less than 0 and no greater than 10.", this.Text,
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    if (dialog == DialogResult.Yes) this.Close();
                }
                //Displays error message is x is less than 0
                else if (x < 0)
                {
                    DialogResult dialog = MessageBox.Show("Error: Please enter a value between no less than 0 and no greater than 10.", this.Text,
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    if (dialog == DialogResult.Yes) this.Close();
                }
                //Adds an exception if x is 0 in order to calculate the factorial
                else if (x == 0)
                {
                    listBox.Items.Add(dX + "!: " + "1");
                }
                else
                {
                    //Declares output as 1 in order to make this loop work
                    int output = 1;
                    //Runs a loop that decreases x every time while it is not equal to 1. Multiplies x by output
                    while (x != 1)
                    {
                        output = output * x;
                        x = x - 1;
                    }
                    //Displays the factorial in the list box
                    listBox.Items.Add(dX + "!: " + output);
                }
            }
        }

        private void xTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            // This event handler only allows digits, control characters, the negative symbol, and the period. // The symbol ! means “not”; the symbols && mean “and”. 
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && e.KeyChar != '.' && e.KeyChar != '-')
            {
                e.Handled = true;
                return;
            }
        }

        private void yTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            // This event handler only allows digits, control characters, the negative symbol, and the period. // The symbol ! means “not”; the symbols && mean “and”. 
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && e.KeyChar != '.' && e.KeyChar != '-')
            {
                e.Handled = true;
                return;
            }
        }

        //Click event handler for the reciprocal button
        private void recipButton_Click(object sender, EventArgs e)
        {
            //Declares dX as a double and parses the x text box for dX
            double dX;
            double.TryParse(xTextBox.Text, out dX);

            //Checks to see if values have been entered in the y and x text boxes.
            if (xTextBox.Text == "" || yTextBox.Text == "")
            {
                DialogResult dialog = MessageBox.Show("Error: Please enter a value in the necessary text box(es).", this.Text,
                                MessageBoxButtons.OK, MessageBoxIcon.Warning);
                if (dialog == DialogResult.Yes) this.Close();
            }
            else
            {
                //Produces error message if dX is equal to 0.
                if (dX == 0)
                {
                    DialogResult dialog = MessageBox.Show("Error: Cannot divide by 0. Please enter a number for 'x' that is not 0.", this.Text,
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    if (dialog == DialogResult.Yes) this.Close();
                }
                else
                {
                    //Divides 1 by dX for the reciprocal, displays the result in the list box.
                    double output = 1 / dX;
                    listBox.Items.Add("Reciprocal of " + dX + ": " + output.ToString("N6"));
                }
            }
            
        }

        //Click event handler for the divide button
        private void divideButton_Click(object sender, EventArgs e)
        {
            //Creates double variables dX and dY and parses the text boxes for their value
            double dX, dY;
            double.TryParse(xTextBox.Text, out dX);
            double.TryParse(yTextBox.Text, out dY);
            
            //Checks to see if values have been entered in the y and x text boxes.
            if (xTextBox.Text == "" || yTextBox.Text == "")
            {
                DialogResult dialog = MessageBox.Show("Error: Please enter a value in the necessary text box(es).", this.Text,
                                MessageBoxButtons.OK, MessageBoxIcon.Warning);
                if (dialog == DialogResult.Yes) this.Close();
            }
            else
            {
                //Divides dX by dY and outputs this to the list box
                double output = dX / dY;
                listBox.Items.Add("Quotient of " + dX + " divided by " + dY + ": " + output.ToString("N2"));
            }
            }

        //Click event handler for the minus button
        private void minusButton_Click(object sender, EventArgs e)
        {
            //Parses the text boxes to grab the x and y values
            int.TryParse(xTextBox.Text, out x);
            int.TryParse(yTextBox.Text, out y);

            //Checks to see if values have been entered in the y and x text boxes.
            if (xTextBox.Text == "" || yTextBox.Text == "")
            {
                DialogResult dialog = MessageBox.Show("Error: Please enter a value in the necessary text box(es).", this.Text,
                                MessageBoxButtons.OK, MessageBoxIcon.Warning);
                if (dialog == DialogResult.Yes) this.Close();
            }
            else
            {
                //Subtracts y from x and displays the result in the list box
                output = x - y;
                listBox.Items.Add("Difference of " + x + " and " + y + ": " + output);
            }
           
        }

        //Click event handler for the prime button
        private void primeButton_Click(object sender, EventArgs e)
        {
            //Parses the text boxes to grab the x and y values
            int.TryParse(xTextBox.Text, out x);
            int.TryParse(yTextBox.Text, out y);

            //Checks to see if values have been entered in the y and x text boxes.
            if (xTextBox.Text == "" || yTextBox.Text == "")
            {
                DialogResult dialog = MessageBox.Show("Error: Please enter a value in the necessary text box(es).", this.Text,
                                MessageBoxButtons.OK, MessageBoxIcon.Warning);
                if (dialog == DialogResult.Yes) this.Close();
            }

            else
            {
                //Produces error message if x is greater than y
                if (x > y)
                {
                    DialogResult dialog = MessageBox.Show("Error: Please enter a value for 'x' that is less than the value for 'y'.", this.Text,
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    if (dialog == DialogResult.Yes) this.Close();
                }
                //Produces error message if x is less than or equal to 0
                else if (x <= 0)
                {
                    DialogResult dialog = MessageBox.Show("Error: Please enter a value for 'x' that is greater than '0'.", this.Text,
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    if (dialog == DialogResult.Yes) this.Close();
                }
                //Produces error message if y is greater than 500
                else if (y > 500)
                {
                    DialogResult dialog = MessageBox.Show("Error: Please enter a value for 'y' that is less than or equal to '500'.", this.Text,
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    if (dialog == DialogResult.Yes) this.Close();
                }



                else
                {
                    //Declares some variables as doubles
                    double divide, limit = y / 2, test = 0;
                    
                    //Loop used to decrease y decrementally. This allows us to run a "test" on each number between x and y.
                    while (x <= y)
                    {
                        test = 0;
                        limit = y / 2;
                        
                        /*For loop that iterates until divide is greater than limit. If y can be divided by the variable "divide" and produce no remainder,
                        it is not a prime number. "Test" variable will then be set to 1 which is used to determine if a number is a prime number. */
                        for (divide = 2; divide <= limit; divide++)
                        {
                            if (y % divide == 0)
                            {
                                //Displays to the list box that y is not prime.
                                listBox.Items.Add(y + " is not a prime number");
                                
                                test = 1;
                                break;
                            }
                        }

                        //If y isn't prime, test is set to 1. This checks if test is equal to 0, if so, the number has to be prime.
                        if (test == 0)
                        {
                            listBox.Items.Add(y + " is a prime number");
                        }

                        //decrements y each passthrough of the loop
                        y -= 1;
                    }
                }
            }

            
        }

        private void sumButton_Click(object sender, EventArgs e)
        {

            

        }

        //Click event handler for the standard deviation button
        private void stddevButton_Click(object sender, EventArgs e)
        {
            //Declares some variables and parses the text boxes to fill these variables
            double dX, dY;
            double.TryParse(xTextBox.Text, out dX);
            double.TryParse(yTextBox.Text, out dY);
            
            int n = 0, usedN;
            //creates secondary variables for dX and dY used when outputting the values to the list box (since dX and dY get manipulated during the process)
            double xTwo = dX, yTwo = dY;
            double sumSquares = 0, preSqrt;

            //Checks to see if values have been entered in the y and x text boxes.
            if (xTextBox.Text == "" || yTextBox.Text == "")
            {
                DialogResult dialog = MessageBox.Show("Error: Please enter a value in the necessary text box(es).", this.Text,
                                MessageBoxButtons.OK, MessageBoxIcon.Warning);
                if (dialog == DialogResult.Yes) this.Close();
            }
            else
            {
                //Error message if both dX and dY are equal to 0
                if (dX == 0 && dY == 0)
                {
                    DialogResult dialog = MessageBox.Show("Error: Cannot compute standard deviation when both 'x' and 'y' are 0.", this.Text,
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    if (dialog == DialogResult.Yes) this.Close();
                }
                else
                {
                    //If dX is greater than dY, switches the variables using the temporary variable tempInt
                    if (dX > dY)
                    {
                        double tempInt = dX;
                        dX = dY;
                        dY = tempInt;
                    }

                    //For loop that iterates through the values between dX and Dy in order to increment the 'n' variable used in the calculation
                    double i;
                    for (i = dX; i <= dY; i++)
                    {
                        n += 1;
                    }


                    //Creates some variable used in the calculation ahead
                    usedN = n - 1;
                    double mean = (dX + dY) / 2;


                    //loop to calculate deviation, squared deviations, and the sum of these squared deviations which will later be used in the calculation
                    while (dX <= dY)
                    {

                        double deviation = dX - mean;
                        double devSquare = deviation * deviation;
                        sumSquares += devSquare;
                        //increments dX in order to run through the values between dX and dY
                        dX += 1;
                    }

                    //performs the division aspect of the calculation by dividing sumSquares by usedN.
                    preSqrt = sumSquares / usedN;

                    //Takes the square root of preSqrt and outputs this value to the listbox
                    output = Math.Sqrt(preSqrt);
                    listBox.Items.Add("Standard deviation for range " + xTwo + " to " + yTwo + ": " + output.ToString("N6"));
                }
            }
            

        }

        //Click event handler for the multiplication table button
        private void tableButton_Click(object sender, EventArgs e)
        {

            //parses the x text box value and outputs it as x
            int.TryParse(xTextBox.Text, out x);

            //Checks to see if values have been entered in the y and x text boxes.
            if (xTextBox.Text == "" || yTextBox.Text == "")
            {
                DialogResult dialog = MessageBox.Show("Error: Please enter a value in the necessary text box(es).", this.Text,
                                MessageBoxButtons.OK, MessageBoxIcon.Warning);
                if (dialog == DialogResult.Yes) this.Close();
            }
            else
            {
                //Produces error message is x is greater than 12
                if (x > 12)
                {
                    DialogResult dialog = MessageBox.Show("Error: Please enter a value for x that is between 1-12.", this.Text,
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    if (dialog == DialogResult.Yes) this.Close();
                }

                //Produces error message is x is less than 1
                else if (x < 1)
                {
                    DialogResult dialog = MessageBox.Show("Error: Please enter a value for x that is between 1-12.", this.Text,
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    if (dialog == DialogResult.Yes) this.Close();
                }
                else
                {
                    int multTable = 1;
                    //while loop to incrementally increase the multTable variable and add the respective calculation for each value between 1-12.
                    while (multTable <= 12)
                    {

                        listBox.Items.Add(multTable + " * " + x + " = " + multTable * x);
                        multTable += 1;
                    }
                }
            }
           
        }

        //Click event handler for the Sum of Squares Button
        private void sumSquareButton_Click(object sender, EventArgs e)
        {
            //Parses the x and y text boxes and outputs the value to the x and y variables respectively
            int.TryParse(xTextBox.Text, out x);
            int.TryParse(yTextBox.Text, out y);
            //Checks to see if values have been entered in the y and x text boxes.
            if (xTextBox.Text == "" || yTextBox.Text == "")
            {
                DialogResult dialog = MessageBox.Show("Error: Please enter a value in the necessary text box(es).", this.Text,
                                MessageBoxButtons.OK, MessageBoxIcon.Warning);
                if (dialog == DialogResult.Yes) this.Close();
            }

            else
            {
                //Error message if x is less than y
                if (x > y)
                {
                    DialogResult dialog = MessageBox.Show("Error: Please enter a value for 'x' that is less than 'y'.", this.Text,
                                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    if (dialog == DialogResult.Yes) this.Close();
                }
                //Error message if x and y equal 0
                else if (x == 0 && y == 0)
                {
                    DialogResult dialog = MessageBox.Show("Error: Please enter a value for 'x' and 'y' that is greater than 0.", this.Text,
                                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    if (dialog == DialogResult.Yes) this.Close();
                }
                else
                {
                    int numAdd = 0, squareAdd = 0;
                    
                    //while loop that iterates through the values between x and y, squaring them and adding necessary values to the numAdd and squareAdd variables
                    //to be used for the final line output of the button.
                    while (x <= y)
                    {
                        int numSquare = x * x;

                        //Adds the current value of x and numSquare to numAdd and squareAdd respectively for each passthrough of the loop
                        numAdd += x;
                        squareAdd += numSquare;

                        //outputs the results to the list box
                        listBox.Items.Add("The number is: " + x + " and its square is: " + numSquare);
                        x += 1;


                    }
                    //Adds a blank line
                    listBox.Items.Add("");
                    //Displays the sum of numbers and squares
                    listBox.Items.Add("Sum of numbers: " + numAdd + " Sum of squares: " + squareAdd);
                }
            }
           


        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void xTextBox_Click(object sender, EventArgs e)
        {
            //Automatic selection for the text box, also focuses the text box
            xTextBox.SelectAll();
            xTextBox.Focus();
        }

        private void xTextBox_Enter(object sender, EventArgs e)
        {
            //Automatic selection for the text box, also focuses the text box
            xTextBox.SelectAll();
            xTextBox.Focus();
        }

        private void yTextBox_Enter(object sender, EventArgs e)
        {
            //Automatic selection for the text box, also focuses the text box
            yTextBox.SelectAll();
            yTextBox.Focus();
        }

        private void yTextBox_Click(object sender, EventArgs e)
        {
            //Automatic selection for the text box, also focuses the text box
            yTextBox.SelectAll();
            yTextBox.Focus();
        }

        private void xTextBox_TextChanged(object sender, EventArgs e)
        {
            //Clears the x text box upon the text changing event
            listBox.Items.Clear();
        }

        private void yTextBox_TextChanged(object sender, EventArgs e)
        {
            ////Clears the y text box upon the text changing event
            listBox.Items.Clear();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            // Gives a confirmation window to close the program
            DialogResult dialog = MessageBox.Show("Are you sure you want to exit?", this.Text,
                MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            if (dialog == DialogResult.Yes) this.Close();
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            //Clears the list box on the click event for the clear button
            listBox.Items.Clear();
        }

        private void powerButton_Click(object sender, EventArgs e)
        {
            //Parses the x and y text boxes and outputs the value to the x and y variables respectively
            int.TryParse(xTextBox.Text, out x);
            int.TryParse(yTextBox.Text, out y);
            
            //Checks to see if values have been entered in the y and x text boxes.
            if (xTextBox.Text == "" || yTextBox.Text == "")
            {
                DialogResult dialog = MessageBox.Show("Error: Please enter a value in the necessary text box(es).", this.Text,
                                MessageBoxButtons.OK, MessageBoxIcon.Warning);
                if (dialog == DialogResult.Yes) this.Close();
            }
            else
            {
                //Computes x raised to the y and outputs the value to the listbox
                double output = Math.Pow(x, y);
                listBox.Items.Add(x + " raised to the power of " + y + ": " + output.ToString("N1"));
            }
        }
    }
}
