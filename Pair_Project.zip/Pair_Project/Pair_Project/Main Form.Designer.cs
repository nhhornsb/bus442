﻿
namespace Pair_Project
{
    partial class MainForm
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.powerButton = new System.Windows.Forms.Button();
            this.xTextBox = new System.Windows.Forms.TextBox();
            this.yTextBox = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.divideButton = new System.Windows.Forms.Button();
            this.addButton = new System.Windows.Forms.Button();
            this.facButton = new System.Windows.Forms.Button();
            this.recipButton = new System.Windows.Forms.Button();
            this.minusButton = new System.Windows.Forms.Button();
            this.primeButton = new System.Windows.Forms.Button();
            this.listBox = new System.Windows.Forms.ListBox();
            this.sumButton = new System.Windows.Forms.Button();
            this.stddevButton = new System.Windows.Forms.Button();
            this.tableButton = new System.Windows.Forms.Button();
            this.sumSquareButton = new System.Windows.Forms.Button();
            this.sumFileButton = new System.Windows.Forms.Button();
            this.rangeButton = new System.Windows.Forms.Button();
            this.averageButton = new System.Windows.Forms.Button();
            this.arrayValueButton = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.yCheckBox = new System.Windows.Forms.CheckBox();
            this.oneButton = new System.Windows.Forms.Button();
            this.twoButton = new System.Windows.Forms.Button();
            this.threeButton = new System.Windows.Forms.Button();
            this.fourButton = new System.Windows.Forms.Button();
            this.fiveButton = new System.Windows.Forms.Button();
            this.sevenButton = new System.Windows.Forms.Button();
            this.zeroButton = new System.Windows.Forms.Button();
            this.sixButton = new System.Windows.Forms.Button();
            this.eightButton = new System.Windows.Forms.Button();
            this.nineButton = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.displayButton = new System.Windows.Forms.Button();
            this.clearButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // powerButton
            // 
            this.powerButton.Location = new System.Drawing.Point(29, 237);
            this.powerButton.Name = "powerButton";
            this.powerButton.Size = new System.Drawing.Size(101, 35);
            this.powerButton.TabIndex = 0;
            this.powerButton.Text = "x&^y";
            this.powerButton.UseVisualStyleBackColor = true;
            this.powerButton.Click += new System.EventHandler(this.powerButton_Click);
            // 
            // xTextBox
            // 
            this.xTextBox.Location = new System.Drawing.Point(423, 237);
            this.xTextBox.MaxLength = 10;
            this.xTextBox.Name = "xTextBox";
            this.xTextBox.Size = new System.Drawing.Size(90, 23);
            this.xTextBox.TabIndex = 1;
            this.xTextBox.Click += new System.EventHandler(this.xTextBox_Click);
            this.xTextBox.TextChanged += new System.EventHandler(this.xTextBox_TextChanged);
            this.xTextBox.Enter += new System.EventHandler(this.xTextBox_Enter);
            this.xTextBox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.xTextBox_KeyPress);
            // 
            // yTextBox
            // 
            this.yTextBox.Location = new System.Drawing.Point(423, 269);
            this.yTextBox.MaxLength = 10;
            this.yTextBox.Name = "yTextBox";
            this.yTextBox.Size = new System.Drawing.Size(90, 23);
            this.yTextBox.TabIndex = 2;
            this.yTextBox.Click += new System.EventHandler(this.yTextBox_Click);
            this.yTextBox.TextChanged += new System.EventHandler(this.yTextBox_TextChanged);
            this.yTextBox.Enter += new System.EventHandler(this.yTextBox_Enter);
            this.yTextBox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.yTextBox_KeyPress);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Silver;
            this.label1.Location = new System.Drawing.Point(401, 240);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(16, 15);
            this.label1.TabIndex = 4;
            this.label1.Text = "x:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Silver;
            this.label2.Location = new System.Drawing.Point(401, 269);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(16, 15);
            this.label2.TabIndex = 5;
            this.label2.Text = "y:";
            // 
            // divideButton
            // 
            this.divideButton.Location = new System.Drawing.Point(154, 237);
            this.divideButton.Name = "divideButton";
            this.divideButton.Size = new System.Drawing.Size(97, 35);
            this.divideButton.TabIndex = 6;
            this.divideButton.Text = "x&/y";
            this.divideButton.UseVisualStyleBackColor = true;
            this.divideButton.Click += new System.EventHandler(this.divideButton_Click);
            // 
            // addButton
            // 
            this.addButton.Location = new System.Drawing.Point(269, 237);
            this.addButton.Name = "addButton";
            this.addButton.Size = new System.Drawing.Size(95, 35);
            this.addButton.TabIndex = 7;
            this.addButton.Text = "x&+y";
            this.addButton.UseVisualStyleBackColor = true;
            this.addButton.Click += new System.EventHandler(this.addButton_Click);
            // 
            // facButton
            // 
            this.facButton.Location = new System.Drawing.Point(29, 283);
            this.facButton.Name = "facButton";
            this.facButton.Size = new System.Drawing.Size(101, 35);
            this.facButton.TabIndex = 8;
            this.facButton.Text = "x&!";
            this.facButton.UseVisualStyleBackColor = true;
            this.facButton.Click += new System.EventHandler(this.facButton_Click);
            // 
            // recipButton
            // 
            this.recipButton.Location = new System.Drawing.Point(154, 283);
            this.recipButton.Name = "recipButton";
            this.recipButton.Size = new System.Drawing.Size(97, 35);
            this.recipButton.TabIndex = 9;
            this.recipButton.Text = "&1/x";
            this.recipButton.UseVisualStyleBackColor = true;
            this.recipButton.Click += new System.EventHandler(this.recipButton_Click);
            // 
            // minusButton
            // 
            this.minusButton.Location = new System.Drawing.Point(269, 283);
            this.minusButton.Name = "minusButton";
            this.minusButton.Size = new System.Drawing.Size(95, 35);
            this.minusButton.TabIndex = 10;
            this.minusButton.Text = "x&-y";
            this.minusButton.UseVisualStyleBackColor = true;
            this.minusButton.Click += new System.EventHandler(this.minusButton_Click);
            // 
            // primeButton
            // 
            this.primeButton.Location = new System.Drawing.Point(29, 324);
            this.primeButton.Name = "primeButton";
            this.primeButton.Size = new System.Drawing.Size(101, 44);
            this.primeButton.TabIndex = 11;
            this.primeButton.Text = "&Prime";
            this.primeButton.UseVisualStyleBackColor = true;
            this.primeButton.Click += new System.EventHandler(this.primeButton_Click);
            // 
            // listBox
            // 
            this.listBox.FormattingEnabled = true;
            this.listBox.ItemHeight = 15;
            this.listBox.Location = new System.Drawing.Point(29, 82);
            this.listBox.Name = "listBox";
            this.listBox.Size = new System.Drawing.Size(335, 139);
            this.listBox.TabIndex = 12;
            // 
            // sumButton
            // 
            this.sumButton.Location = new System.Drawing.Point(154, 380);
            this.sumButton.Name = "sumButton";
            this.sumButton.Size = new System.Drawing.Size(97, 42);
            this.sumButton.TabIndex = 13;
            this.sumButton.Text = "Ma&x of File Values";
            this.sumButton.UseVisualStyleBackColor = true;
            this.sumButton.Click += new System.EventHandler(this.sumButton_Click);
            // 
            // stddevButton
            // 
            this.stddevButton.Location = new System.Drawing.Point(154, 324);
            this.stddevButton.Name = "stddevButton";
            this.stddevButton.Size = new System.Drawing.Size(97, 44);
            this.stddevButton.TabIndex = 14;
            this.stddevButton.Text = "Sta&ndard Deviation of x:y";
            this.stddevButton.UseVisualStyleBackColor = true;
            this.stddevButton.Click += new System.EventHandler(this.stddevButton_Click);
            // 
            // tableButton
            // 
            this.tableButton.Location = new System.Drawing.Point(269, 324);
            this.tableButton.Name = "tableButton";
            this.tableButton.Size = new System.Drawing.Size(95, 44);
            this.tableButton.TabIndex = 15;
            this.tableButton.Text = "Multiplication &Table of x";
            this.tableButton.UseVisualStyleBackColor = true;
            this.tableButton.Click += new System.EventHandler(this.tableButton_Click);
            // 
            // sumSquareButton
            // 
            this.sumSquareButton.Location = new System.Drawing.Point(29, 380);
            this.sumSquareButton.Name = "sumSquareButton";
            this.sumSquareButton.Size = new System.Drawing.Size(101, 42);
            this.sumSquareButton.TabIndex = 16;
            this.sumSquareButton.Text = "&Sum of Squares";
            this.sumSquareButton.UseVisualStyleBackColor = true;
            this.sumSquareButton.Click += new System.EventHandler(this.sumSquareButton_Click);
            // 
            // sumFileButton
            // 
            this.sumFileButton.Location = new System.Drawing.Point(269, 380);
            this.sumFileButton.Name = "sumFileButton";
            this.sumFileButton.Size = new System.Drawing.Size(97, 42);
            this.sumFileButton.TabIndex = 17;
            this.sumFileButton.Text = "Sum of &File Values";
            this.sumFileButton.UseVisualStyleBackColor = true;
            // 
            // rangeButton
            // 
            this.rangeButton.Location = new System.Drawing.Point(29, 428);
            this.rangeButton.Name = "rangeButton";
            this.rangeButton.Size = new System.Drawing.Size(101, 42);
            this.rangeButton.TabIndex = 18;
            this.rangeButton.Text = "&Range of File Values";
            this.rangeButton.UseVisualStyleBackColor = true;
            // 
            // averageButton
            // 
            this.averageButton.Location = new System.Drawing.Point(154, 428);
            this.averageButton.Name = "averageButton";
            this.averageButton.Size = new System.Drawing.Size(97, 42);
            this.averageButton.TabIndex = 19;
            this.averageButton.Text = "&Average of File Values";
            this.averageButton.UseVisualStyleBackColor = true;
            // 
            // arrayValueButton
            // 
            this.arrayValueButton.Location = new System.Drawing.Point(269, 428);
            this.arrayValueButton.Name = "arrayValueButton";
            this.arrayValueButton.Size = new System.Drawing.Size(97, 42);
            this.arrayValueButton.TabIndex = 20;
            this.arrayValueButton.Text = "File Array &Value at (x,y)";
            this.arrayValueButton.UseVisualStyleBackColor = true;
            // 
            // label3
            // 
            this.label3.BackColor = System.Drawing.Color.Silver;
            this.label3.Font = new System.Drawing.Font("Segoe UI", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label3.ForeColor = System.Drawing.Color.Maroon;
            this.label3.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.label3.Location = new System.Drawing.Point(54, 13);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(281, 66);
            this.label3.TabIndex = 21;
            this.label3.Text = "Calculator App";
            // 
            // label4
            // 
            this.label4.BackColor = System.Drawing.Color.Silver;
            this.label4.Font = new System.Drawing.Font("Segoe UI", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label4.ForeColor = System.Drawing.Color.Maroon;
            this.label4.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.label4.Location = new System.Drawing.Point(372, 82);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(151, 397);
            this.label4.TabIndex = 22;
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // yCheckBox
            // 
            this.yCheckBox.AutoSize = true;
            this.yCheckBox.BackColor = System.Drawing.Color.Silver;
            this.yCheckBox.Location = new System.Drawing.Point(380, 273);
            this.yCheckBox.Name = "yCheckBox";
            this.yCheckBox.Size = new System.Drawing.Size(15, 14);
            this.yCheckBox.TabIndex = 23;
            this.yCheckBox.UseVisualStyleBackColor = false;
            // 
            // oneButton
            // 
            this.oneButton.BackColor = System.Drawing.Color.Black;
            this.oneButton.ForeColor = System.Drawing.Color.White;
            this.oneButton.Location = new System.Drawing.Point(402, 157);
            this.oneButton.Name = "oneButton";
            this.oneButton.Size = new System.Drawing.Size(33, 31);
            this.oneButton.TabIndex = 24;
            this.oneButton.Text = "1";
            this.oneButton.UseVisualStyleBackColor = false;
            // 
            // twoButton
            // 
            this.twoButton.BackColor = System.Drawing.Color.Black;
            this.twoButton.ForeColor = System.Drawing.Color.White;
            this.twoButton.Location = new System.Drawing.Point(434, 157);
            this.twoButton.Name = "twoButton";
            this.twoButton.Size = new System.Drawing.Size(33, 31);
            this.twoButton.TabIndex = 25;
            this.twoButton.Text = "2";
            this.twoButton.UseVisualStyleBackColor = false;
            this.twoButton.Click += new System.EventHandler(this.button1_Click);
            // 
            // threeButton
            // 
            this.threeButton.BackColor = System.Drawing.Color.Black;
            this.threeButton.ForeColor = System.Drawing.Color.White;
            this.threeButton.Location = new System.Drawing.Point(466, 157);
            this.threeButton.Name = "threeButton";
            this.threeButton.Size = new System.Drawing.Size(33, 31);
            this.threeButton.TabIndex = 26;
            this.threeButton.Text = "3";
            this.threeButton.UseVisualStyleBackColor = false;
            // 
            // fourButton
            // 
            this.fourButton.BackColor = System.Drawing.Color.Black;
            this.fourButton.ForeColor = System.Drawing.Color.White;
            this.fourButton.Location = new System.Drawing.Point(402, 126);
            this.fourButton.Name = "fourButton";
            this.fourButton.Size = new System.Drawing.Size(33, 31);
            this.fourButton.TabIndex = 27;
            this.fourButton.Text = "4";
            this.fourButton.UseVisualStyleBackColor = false;
            // 
            // fiveButton
            // 
            this.fiveButton.BackColor = System.Drawing.Color.Black;
            this.fiveButton.ForeColor = System.Drawing.Color.White;
            this.fiveButton.Location = new System.Drawing.Point(434, 126);
            this.fiveButton.Name = "fiveButton";
            this.fiveButton.Size = new System.Drawing.Size(33, 31);
            this.fiveButton.TabIndex = 28;
            this.fiveButton.Text = "5";
            this.fiveButton.UseVisualStyleBackColor = false;
            // 
            // sevenButton
            // 
            this.sevenButton.BackColor = System.Drawing.Color.Black;
            this.sevenButton.ForeColor = System.Drawing.Color.White;
            this.sevenButton.Location = new System.Drawing.Point(402, 95);
            this.sevenButton.Name = "sevenButton";
            this.sevenButton.Size = new System.Drawing.Size(33, 31);
            this.sevenButton.TabIndex = 29;
            this.sevenButton.Text = "7";
            this.sevenButton.UseVisualStyleBackColor = false;
            // 
            // zeroButton
            // 
            this.zeroButton.BackColor = System.Drawing.Color.Black;
            this.zeroButton.ForeColor = System.Drawing.Color.White;
            this.zeroButton.Location = new System.Drawing.Point(434, 188);
            this.zeroButton.Name = "zeroButton";
            this.zeroButton.Size = new System.Drawing.Size(33, 31);
            this.zeroButton.TabIndex = 30;
            this.zeroButton.Text = "0";
            this.zeroButton.UseVisualStyleBackColor = false;
            // 
            // sixButton
            // 
            this.sixButton.BackColor = System.Drawing.Color.Black;
            this.sixButton.ForeColor = System.Drawing.Color.White;
            this.sixButton.Location = new System.Drawing.Point(466, 126);
            this.sixButton.Name = "sixButton";
            this.sixButton.Size = new System.Drawing.Size(33, 31);
            this.sixButton.TabIndex = 31;
            this.sixButton.Text = "6";
            this.sixButton.UseVisualStyleBackColor = false;
            // 
            // eightButton
            // 
            this.eightButton.BackColor = System.Drawing.Color.Black;
            this.eightButton.ForeColor = System.Drawing.Color.White;
            this.eightButton.Location = new System.Drawing.Point(434, 95);
            this.eightButton.Name = "eightButton";
            this.eightButton.Size = new System.Drawing.Size(33, 31);
            this.eightButton.TabIndex = 32;
            this.eightButton.Text = "8";
            this.eightButton.UseVisualStyleBackColor = false;
            // 
            // nineButton
            // 
            this.nineButton.BackColor = System.Drawing.Color.Black;
            this.nineButton.ForeColor = System.Drawing.Color.White;
            this.nineButton.Location = new System.Drawing.Point(466, 95);
            this.nineButton.Name = "nineButton";
            this.nineButton.Size = new System.Drawing.Size(33, 31);
            this.nineButton.TabIndex = 33;
            this.nineButton.Text = "9";
            this.nineButton.UseVisualStyleBackColor = false;
            // 
            // button8
            // 
            this.button8.BackColor = System.Drawing.Color.Maroon;
            this.button8.ForeColor = System.Drawing.Color.White;
            this.button8.Location = new System.Drawing.Point(402, 188);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(33, 31);
            this.button8.TabIndex = 34;
            this.button8.Text = "C";
            this.button8.UseVisualStyleBackColor = false;
            // 
            // button9
            // 
            this.button9.BackColor = System.Drawing.Color.Maroon;
            this.button9.Font = new System.Drawing.Font("Segoe UI", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.button9.ForeColor = System.Drawing.Color.White;
            this.button9.Location = new System.Drawing.Point(466, 188);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(33, 31);
            this.button9.TabIndex = 35;
            this.button9.Text = "CE";
            this.button9.UseVisualStyleBackColor = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(401, 13);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(97, 67);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 36;
            this.pictureBox1.TabStop = false;
            // 
            // displayButton
            // 
            this.displayButton.BackColor = System.Drawing.Color.Silver;
            this.displayButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.displayButton.Location = new System.Drawing.Point(380, 324);
            this.displayButton.Name = "displayButton";
            this.displayButton.Size = new System.Drawing.Size(133, 44);
            this.displayButton.TabIndex = 37;
            this.displayButton.Text = "&Display File";
            this.displayButton.UseVisualStyleBackColor = false;
            // 
            // clearButton
            // 
            this.clearButton.BackColor = System.Drawing.Color.Silver;
            this.clearButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.clearButton.Location = new System.Drawing.Point(380, 378);
            this.clearButton.Name = "clearButton";
            this.clearButton.Size = new System.Drawing.Size(133, 44);
            this.clearButton.TabIndex = 38;
            this.clearButton.Text = "C&lear Results";
            this.clearButton.UseVisualStyleBackColor = false;
            this.clearButton.Click += new System.EventHandler(this.clearButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.BackColor = System.Drawing.Color.Silver;
            this.exitButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.exitButton.Location = new System.Drawing.Point(380, 428);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(133, 44);
            this.exitButton.TabIndex = 39;
            this.exitButton.Text = "E&xit";
            this.exitButton.UseVisualStyleBackColor = false;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // MainForm
            // 
            this.AcceptButton = this.displayButton;
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.exitButton;
            this.ClientSize = new System.Drawing.Size(550, 488);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.clearButton);
            this.Controls.Add(this.displayButton);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.button9);
            this.Controls.Add(this.button8);
            this.Controls.Add(this.nineButton);
            this.Controls.Add(this.eightButton);
            this.Controls.Add(this.sixButton);
            this.Controls.Add(this.zeroButton);
            this.Controls.Add(this.sevenButton);
            this.Controls.Add(this.fiveButton);
            this.Controls.Add(this.fourButton);
            this.Controls.Add(this.threeButton);
            this.Controls.Add(this.twoButton);
            this.Controls.Add(this.oneButton);
            this.Controls.Add(this.yCheckBox);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.arrayValueButton);
            this.Controls.Add(this.averageButton);
            this.Controls.Add(this.rangeButton);
            this.Controls.Add(this.sumFileButton);
            this.Controls.Add(this.sumSquareButton);
            this.Controls.Add(this.tableButton);
            this.Controls.Add(this.stddevButton);
            this.Controls.Add(this.sumButton);
            this.Controls.Add(this.listBox);
            this.Controls.Add(this.primeButton);
            this.Controls.Add(this.minusButton);
            this.Controls.Add(this.recipButton);
            this.Controls.Add(this.facButton);
            this.Controls.Add(this.addButton);
            this.Controls.Add(this.divideButton);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.yTextBox);
            this.Controls.Add(this.xTextBox);
            this.Controls.Add(this.powerButton);
            this.Controls.Add(this.label4);
            this.Name = "MainForm";
            this.Text = "Calculator App";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button powerButton;
        private System.Windows.Forms.TextBox xTextBox;
        private System.Windows.Forms.TextBox yTextBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button divideButton;
        private System.Windows.Forms.Button addButton;
        private System.Windows.Forms.Button facButton;
        private System.Windows.Forms.Button recipButton;
        private System.Windows.Forms.Button minusButton;
        private System.Windows.Forms.Button primeButton;
        private System.Windows.Forms.ListBox listBox;
        private System.Windows.Forms.Button sumButton;
        private System.Windows.Forms.Button stddevButton;
        private System.Windows.Forms.Button tableButton;
        private System.Windows.Forms.Button sumSquareButton;
        private System.Windows.Forms.Button sumFileButton;
        private System.Windows.Forms.Button rangeButton;
        private System.Windows.Forms.Button averageButton;
        private System.Windows.Forms.Button arrayValueButton;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.CheckBox yCheckBox;
        private System.Windows.Forms.Button oneButton;
        private System.Windows.Forms.Button twoButton;
        private System.Windows.Forms.Button threeButton;
        private System.Windows.Forms.Button fourButton;
        private System.Windows.Forms.Button fiveButton;
        private System.Windows.Forms.Button sevenButton;
        private System.Windows.Forms.Button zeroButton;
        private System.Windows.Forms.Button sixButton;
        private System.Windows.Forms.Button eightButton;
        private System.Windows.Forms.Button nineButton;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button displayButton;
        private System.Windows.Forms.Button clearButton;
        private System.Windows.Forms.Button exitButton;
    }
}

